package no.hvl.quizappvol2.Activity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import no.hvl.quizappvol2.DAO.ImageItemDAO;
import no.hvl.quizappvol2.ImageDatabase;
import no.hvl.quizappvol2.ImageDatabase_Impl;
import no.hvl.quizappvol2.ImageItem;
import no.hvl.quizappvol2.RecyclerAdapter;
import no.hvl.quizappvol2.R;

public class GalleryActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private RecyclerAdapter adapter;
    private ImageItemDAO imageItemDAO;
    private ActivityResultLauncher<Intent> imagePickerLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recycler_view);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        imageItemDAO = ImageDatabase.getInstance(this).imageItemDAO();


        adapter = new RecyclerAdapter(this, new ArrayList<>()); // Initialize with empty list
        recyclerView.setAdapter(adapter);


        imageItemDAO.getAllImages().observe(this, imageList -> {
            adapter.updateData(imageList);
        });



        imagePickerLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                Uri imageUri = result.getData().getData();
                showDescriptionDialog(imageUri.toString());
            }
        });
    }

    public static void loadImage(Context context, String imagePath, ImageView imageView) {
        if (imagePath.startsWith("assets/")) {
            try {
                AssetManager assetManager = context.getAssets();
                InputStream inputStream = assetManager.open(imagePath.replace("assets/", ""));
                Drawable drawable = Drawable.createFromStream(inputStream, null);
                imageView.setImageDrawable(drawable);
            } catch (IOException e) {
                Log.e("GalleryActivity", "Error loading image from assets", e);
            }
        } else {
            Glide.with(context)
                    .load(imagePath)
                    .into(imageView);
        }
    }


    public void openImagePicker(View view) {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        imagePickerLauncher.launch(intent);
    }

    private void showDescriptionDialog(String imagePath) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add Description");

        final EditText input = new EditText(this);
        builder.setView(input);

        builder.setPositiveButton("Save", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String description = input.getText().toString().trim();
                saveImage(imagePath, description);
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builder.show();
    }

    private void saveImage(String imagePath, String description) {
        ImageItem newItem = new ImageItem(imagePath, description);
        imageItemDAO.insertImage(newItem);
        Toast.makeText(this, "Image added successfully!", Toast.LENGTH_SHORT).show();
    }
}
