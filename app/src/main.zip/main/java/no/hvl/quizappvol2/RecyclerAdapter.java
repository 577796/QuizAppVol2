package no.hvl.quizappvol2;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.ViewHolder> {
    private Context context;
    private List<ImageItem> imageList;

    public RecyclerAdapter(Context context, List<ImageItem> imageList) {
        this.context = context;
        this.imageList = imageList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.custom_single_image, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ImageItem item = imageList.get(position);
        holder.descriptionText.setText(item.getDescription());
        loadImage(context, item.getImagePath(), holder.imageView);
    }

    @Override
    public int getItemCount() {
        return imageList.size();
    }

    public void updateData(List<ImageItem> newList) {
        this.imageList = newList;
        notifyDataSetChanged();
    }

    public static void loadImage(Context context, String imagePath, ImageView imageView) {
        if (imagePath.startsWith("assets/")) {
            try {
                AssetManager assetManager = context.getAssets();
                InputStream inputStream = assetManager.open(imagePath.replace("assets/", ""));
                Drawable drawable = Drawable.createFromStream(inputStream, null);
                imageView.setImageDrawable(drawable);
            } catch (IOException e) {
                Log.e("RecyclerAdapter", "Error loading image from assets", e);
            }
        } else {
            Glide.with(context)
                    .load(imagePath)
                    .into(imageView);
        }
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView descriptionText;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.image);
            descriptionText = itemView.findViewById(R.id.description);
        }
    }
}
