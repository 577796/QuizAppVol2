package no.hvl.quizappvol2;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import android.content.Context;

import no.hvl.quizappvol2.DAO.ImageItemDAO;
import no.hvl.quizappvol2.ImageItem;

@Database(entities = {ImageItem.class}, version = 1, exportSchema = false)
public abstract class ImageDatabase extends RoomDatabase {

    private static ImageDatabase INSTANCE;

    public abstract ImageItemDAO imageItemDAO();

    public static synchronized ImageDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                            ImageDatabase.class, "image_database")
                    .fallbackToDestructiveMigration()
                    .build();
        }
        return INSTANCE;
    }
}
