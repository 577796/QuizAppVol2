package no.hvl.quizappvol2.DAO;

import android.media.Image;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

import no.hvl.quizappvol2.ImageItem;

@Dao
public interface ImageItemDAO {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(ImageItem imageItem);

    @Query("SELECT * FROM image_table")
    List<ImageItem> getAllImages();  // Retrieve all images

    @Delete
    void deleteImage(ImageItem imageItem);
}
