package no.hvl.quizappvol2;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class QuizActivity extends AppCompatActivity {

    private Button answer1, answer2, answer3, next;
    private ImageView quizImage;
    private TextView scoreText;
    private List<ImageItem> quizItems;
    private int currentQuestion;
    private int points;
    private String correctAnswer;



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.quiz_view);

        answer1 = findViewById(R.id.answer1);
        answer2 = findViewById(R.id.answer2);
        answer3 = findViewById(R.id.answer3);
        next = findViewById(R.id.next);
        scoreText = findViewById(R.id.score);
        quizImage = findViewById(R.id.quizImage);

        quizItems = loadFromDB();

        loadNextQuestion();

        answer1.setOnClickListener(view -> checkAnswer(answer1));
        answer2.setOnClickListener(view -> checkAnswer(answer2));
        answer3.setOnClickListener(view -> checkAnswer(answer3));

        next.setOnClickListener(view -> loadNextQuestion());

    }

    private void loadNextQuestion() {
        if(currentQuestion >= quizItems.size()){
            Toast.makeText(this, "Quiz is over!", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        ImageItem currentItem = quizItems.get(currentQuestion);
        correctAnswer = currentItem.getDescription();

        File imgFile = new File(currentItem.getImagePath());
        if(imgFile.exists()){
            Bitmap bitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());
            quizImage.setImageBitmap(bitmap);
        }

        List<String> options = new ArrayList<>();
        options.add(correctAnswer);
        for(ImageItem item : quizItems){
            if (!item.getDescription().equals(correctAnswer) && options.size() < 3){
                    options.add(item.getDescription());
                }
        }

        Collections.shuffle(options);
        answer1.setText(options.get(0));
        answer2.setText(options.get(1));
        answer3.setText(options.get(2));

        answer1.setEnabled(true);
        answer2.setEnabled(true);
        answer3.setEnabled(true);


    }

    private List<ImageItem> loadFromDB() {
        ImageDatabase db = ImageDatabase.getInstance(this);
        List<ImageItem> images = db.imageItemDAO().getAllImages();

        if (images.isEmpty()) {
            Toast.makeText(this, "No images found in the database!", Toast.LENGTH_LONG).show();
        }

        return images;
    }



    private void checkAnswer(Button selectedButton) {
        String selectedAnswer = selectedButton.getText().toString();

        // Disable all buttons after selection
        answer1.setEnabled(false);
        answer2.setEnabled(false);
        answer3.setEnabled(false);

        // Find the correct button
        Button correctButton;
        if (answer1.getText().toString().equals(correctAnswer)) {
            correctButton = answer1;
        } else if (answer2.getText().toString().equals(correctAnswer)) {
            correctButton = answer2;
        } else {
            correctButton = answer3;
        }

        if (selectedAnswer.equals(correctAnswer)) {
            selectedButton.setBackgroundColor(Color.GREEN);  // Correct choice turns green
            points++;
        } else {
            selectedButton.setBackgroundColor(Color.RED);  // Wrong choice turns red
            correctButton.setBackgroundColor(Color.parseColor("#A5D6A7"));  // Subtle green for correct answer
        }

        // Update score
        scoreText.setText(getString(R.string.score) + points);

        // Show Next Question button
        next.setVisibility(View.VISIBLE);
    }
}
